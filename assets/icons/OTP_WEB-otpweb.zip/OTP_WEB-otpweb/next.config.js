module.exports = {
    env:{
       MONGO_URI:"mongodb+srv://otp:inamsaif@cluster0.jnbirzy.mongodb.net/"
    }
}